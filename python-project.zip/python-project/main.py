# PROGRAM APLIKASI KASIR RESTORAN

print("===================================")
print("       APLIKASI KASIR RESTORAN")
print("===================================")

# Inisialisasi variabel
total = 0

# Daftar menu makanan
menu = {
    1: ("Nasi Goreng", 25000),
    2: ("Mie Ayam", 15000),
    3: ("Ayam Geprek", 20000),
    4: ("Sate Ayam", 30000),
    5: ("Bakso", 18000)
}

# Menampilkan menu makanan
while True:
    print("\n========== MENU MAKANAN ==========")
    for nomor, (nama, harga) in menu.items():
        print(f"{nomor}. {nama} - Rp{harga:,}".replace(",", "."))
    
    print("0. Selesai Memilih")
    print("===================================")

    # Input pilihan menu
    pilihan = int(input("Pilih menu (0-5): "))

    # Jika memilih 0, keluar dari perulangan
    if pilihan == 0:
        break

    # Validasi pilihan menu
    if pilihan not in menu:
        print("Pilihan tidak tersedia!")
        continue

    # Input jumlah pesanan
    jumlah = int(input("Masukkan jumlah pesanan: "))

    if jumlah <= 0:
        print("Jumlah pesanan harus lebih dari 0!")
        continue

    # Menghitung subtotal
    nama, harga = menu[pilihan]
    subtotal = harga * jumlah

    # Menambahkan subtotal ke total
    total += subtotal

    print(f"\nPesanan: {nama}")
    print(f"Harga: Rp{harga:,}".replace(",", "."))
    print(f"Jumlah: {jumlah}")
    print(f"Subtotal: Rp{subtotal:,}".replace(",", "."))

# Menghitung diskon
print("\n===================================")
print("          STRUK PEMBAYARAN")
print("===================================")

if total > 200000:
    diskon = 0.20
else:
    diskon = 0

potongan = total * diskon
total_bayar = total - potongan

# Menampilkan struk pembayaran
print(f"Total Belanja : Rp{total:,}".replace(",", "."))
print(f"Diskon        : {diskon * 100:.0f}%")
print(f"Potongan      : Rp{potongan:,.0f}".replace(",", "."))
print("-----------------------------------")
print(f"Total Bayar   : Rp{total_bayar:,.0f}".replace(",", "."))
print("===================================")
print("       TERIMA KASIH")
print("   SELAMAT MENIKMATI MAKANAN")
print("===================================")
